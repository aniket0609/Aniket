using System;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string directoryToMonitor = @"C:\Path"; // Replace with the directory path you want to monitor
        string[] extensionsToMonitor = { ".pdf", ".jpg", ".docx" }; // Replace with the extensions you want to monitor

        Console.WriteLine("Monitoring for files with extensions:");
        foreach (var extension in extensionsToMonitor)
        {
            Console.WriteLine(extension);
        }
        Console.WriteLine("Press Enter to stop.");

        using var cancellationTokenSource = new CancellationTokenSource();
        var monitoringTask = MonitorFilesAccessAsync(directoryToMonitor, extensionsToMonitor, cancellationTokenSource.Token);

        // Wait for either the monitoring task to complete or Enter to be pressed
        await Task.WhenAny(monitoringTask, Task.Run(() => Console.ReadLine()));

        Console.WriteLine("Stopping monitoring...");

        // Cancel the monitoring task
        cancellationTokenSource.Cancel();

        try
        {
            // Await the monitoring task to gracefully complete or throw an OperationCanceledException
            await monitoringTask;
        }
        catch (OperationCanceledException)
        {
            // Monitoring task was canceled
        }

        Console.WriteLine("Monitoring stopped. Press any key to exit.");
        Console.ReadKey();
    }

    static async Task MonitorFilesAccessAsync(string directoryPath, string[] extensions, CancellationToken cancellationToken)
    {
        while (!cancellationToken.IsCancellationRequested)
        {
            try
            {
                var files = GetFilesInDirectory(directoryPath, extensions);

                foreach (var file in files)
                {
                    if (IsFileAccessed(file))
                    {
                        // Collect internal data here
                        Console.WriteLine($"File accessed: {file}");
                        Console.WriteLine("Collecting internal data...");
                        await Task.Delay(1000); // Simulating data collection process
                        Console.WriteLine("Internal data collection completed.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }

            // Adjust the delay interval based on your requirements
            await Task.Delay(TimeSpan.FromSeconds(5));
        }
    }

    static string[] GetFilesInDirectory(string directoryPath, string[] extensions)
    {
        var files = Directory.GetFiles(directoryPath, "*.*", SearchOption.AllDirectories)
            .Where(file => extensions.Contains(Path.GetExtension(file), StringComparer.OrdinalIgnoreCase))
            .ToArray();

        return files;
    }

    static bool IsFileAccessed(string filePath)
    {
        try
        {
            using (var fileStream = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.None))
            {
                return false;
            }
        }
        catch (IOException)
        {
            // File is being accessed
            return true;
        }
    }
}
