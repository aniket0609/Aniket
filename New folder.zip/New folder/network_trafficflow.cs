using System;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

class TrafficAnalyzer
{
    private const int BufferSize = 4096;
    private const int Port = 8080;

    private static byte[] buffer = new byte[BufferSize];
    private static StringBuilder dataBuilder = new StringBuilder();

    private static void Main()
    {
        Console.WriteLine("Traffic Analyzer started...");

        // Create a TCP listener on the specified port
        TcpListener listener = new TcpListener(IPAddress.Any, Port);
        listener.Start();

        while (true)
        {
            Console.WriteLine("Waiting for incoming connections...");

            // Accept a new client connection
            TcpClient client = listener.AcceptTcpClient();
            Console.WriteLine("Client connected: {0}", client.Client.RemoteEndPoint);

            // Start a new task to handle the client connection
            _ = Task.Run(() => HandleClient(client));
        }
    }

    private static async Task HandleClient(TcpClient client)
    {
        NetworkStream stream = client.GetStream();

        while (true)
        {
            // Check if data is available to be read from the socket
            uint bytesAvailable;
            int result = ioctlsocket(client.Client.Handle, FIONREAD, out bytesAvailable);

            if (result != 0 || bytesAvailable == 0)
            {
                break;
            }

            // Read the available data from the socket
            int bytesRead = await stream.ReadAsync(buffer, 0, Math.Min((int)bytesAvailable, BufferSize));

            if (bytesRead == 0)
            {
                break;
            }

            string receivedData = Encoding.ASCII.GetString(buffer, 0, bytesRead);
            dataBuilder.Append(receivedData);

            // Perform analysis on the received data
            AnalyzeData(dataBuilder.ToString());

            // Clear the StringBuilder for the next iteration
            dataBuilder.Clear();
        }

        // Close the client connection
        client.Close();
        Console.WriteLine("Client disconnected: {0}", client.Client.RemoteEndPoint);
    }

    private static void AnalyzeData(string data)
    {
        // Perform analysis on the received data
        // You can implement your own analysis logic here
        // Example: Check for extraneous packets
        Console.WriteLine("Data : {0} ",data);
        if (data.Contains("EXTRA_PACKET"))
        {
            Console.WriteLine("Detected extraneous packet: {0}", data);
        }

        // Example: Check for anomalous traffic patterns
        if (data.Contains("ANOMALY_PATTERN"))
        {
            Console.WriteLine("Detected anomalous traffic pattern: {0}", data);
        }

        // Example: Check for anomalous syntax or structure
        if (data.Contains("ANOMALY_SYNTAX"))
        {
            Console.WriteLine("Detected anomalous syntax: {0}", data);
        }

        // Example: Check for anomalies in file usage initiating connections
        if (data.Contains("ANOMALY_FILE_CONNECTION"))
        {
            Console.WriteLine("Detected anomaly in file usage initiating connection: {0}", data);
        }
    }

    // Win32 API Constants
    private const int FIONREAD = 0x4004667F;

    [DllImport("ws2_32.dll")]
    private static extern int ioctlsocket(IntPtr s, int cmd, out uint arg);
}
