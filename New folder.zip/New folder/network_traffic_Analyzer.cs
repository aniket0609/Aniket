/* If the network communications are lost, meaning the system is no longer connected to the network, 
If there is an error checking the network state, it will display an error message with the corresponding error code
it will display the following message:  */

using System;
using System.Runtime.InteropServices;
using System.Threading;

public class NetworkMonitor
{
    private const int ERROR_SUCCESS = 0;
    private const int ERROR_NO_NETWORK = 1222;

    [DllImport("wininet.dll")]
    private static extern bool InternetGetConnectedState(out int description, int reserved);

    [DllImport("kernel32.dll")]
    private static extern uint GetLastError();

    public static void Main()
    {
        Console.WriteLine("Monitoring network communications...");

        while (true)
        {
            int description;
            if (!InternetGetConnectedState(out description, 0))
            {
                uint error = GetLastError();
                if (error == ERROR_NO_NETWORK)
                {
                    Console.WriteLine("Network communications lost!");
                    // Perform actions to handle the loss of network communications
                }
                else
                {
                    Console.WriteLine("Error checking network state. Error code: " + error);
                }
            }

            Thread.Sleep(5000); // Wait for 5 seconds before checking again
        }
    }
}
