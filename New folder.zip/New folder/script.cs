using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

class ScriptMonitor
{
    const int FILE_NOTIFY_CHANGE_FILE_NAME = 0x00000001;
    const int FILE_NOTIFY_CHANGE_LAST_WRITE = 0x00000010;
    const int FILE_NOTIFY_CHANGE_SECURITY = 0x00000100;

    const int FILE_ACTION_ADDED = 0x00000001;
    const int FILE_ACTION_REMOVED = 0x00000002;
    const int FILE_ACTION_MODIFIED = 0x00000003;
    const int FILE_ACTION_RENAMED_OLD_NAME = 0x00000004;
    const int FILE_ACTION_RENAMED_NEW_NAME = 0x00000005;

    [StructLayout(LayoutKind.Sequential)]
    struct FILE_NOTIFY_INFORMATION
    {
        public int NextEntryOffset;
        public int Action;
        public int FileNameLength;
        public char FileName; // Changed to char instead of IntPtr
    }

    [DllImport("kernel32.dll")]
    static extern IntPtr CreateFile(
        string lpFileName,
        uint dwDesiredAccess,
        uint dwShareMode,
        IntPtr lpSecurityAttributes,
        uint dwCreationDisposition,
        uint dwFlagsAndAttributes,
        IntPtr hTemplateFile
    );

    [DllImport("kernel32.dll")]
    static extern bool ReadDirectoryChangesW(
        IntPtr hDirectory,
        IntPtr lpBuffer,
        uint nBufferLength,
        bool bWatchSubtree,
        uint dwNotifyFilter,
        out uint lpBytesReturned,
        IntPtr lpOverlapped,
        IntPtr lpCompletionRoutine
    );

    [DllImport("kernel32.dll")]
    static extern bool CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    static extern bool GetFinalPathNameByHandle(
        IntPtr hFile,
        [MarshalAs(UnmanagedType.LPTStr)] StringBuilder lpszFilePath,
        int cchFilePath,
        int dwFlags
    );

    static void Main()
    {
        string directoryToMonitor = @"C:\Users\Z004SU2S\Desktop\New folder"; // Change this to the directory you want to monitor

        IntPtr directoryHandle = CreateFile(
            directoryToMonitor,
            0x0001, // FILE_LIST_DIRECTORY
            0x0007, // FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE
            IntPtr.Zero,
            3, // OPEN_EXISTING
            0x02000000, // FILE_FLAG_BACKUP_SEMANTICS
            IntPtr.Zero
        );

        if (directoryHandle == IntPtr.Zero)
        {
            Console.WriteLine("Failed to open the directory for monitoring.");
            return;
        }

        byte[] buffer = new byte[4096];
        IntPtr bufferPtr = Marshal.AllocHGlobal(buffer.Length);

        bool directoryChanged = false;
        List<string> removedFiles = new List<string>();

        try
        {
            while (true)
            {
                uint bytesReturned;
                bool result = ReadDirectoryChangesW(
                    directoryHandle,
                    bufferPtr,
                    (uint)buffer.Length,
                    false,
                    FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SECURITY,
                    out bytesReturned,
                    IntPtr.Zero,
                    IntPtr.Zero
                );

                if (!result)
                {
                    Console.WriteLine("Failed to read directory changes.");
                    break;
                }

                if (!directoryChanged)
                {
                    Console.WriteLine($"Monitoring directory: {directoryToMonitor}");
                    directoryChanged = true;
                }

                int offset = 0;
                while (offset < bytesReturned)
                {
                    FILE_NOTIFY_INFORMATION notifyInfo = Marshal.PtrToStructure<FILE_NOTIFY_INFORMATION>(bufferPtr + offset);
                    StringBuilder fileName = new StringBuilder(notifyInfo.FileNameLength);
                    fileName.Append(notifyInfo.FileName, notifyInfo.FileNameLength / 2); // Divide by 2 to account for Unicode characters

                    string filePath = Path.Combine(directoryToMonitor, fileName.ToString());

                    switch (notifyInfo.Action)
                    {
                        case FILE_ACTION_ADDED:
                            Console.WriteLine($"Script file added: {GetNormalizedFilePath(filePath)}");
                            CaptureScriptFile(filePath);
                            break;
                        case FILE_ACTION_MODIFIED:
                            Console.WriteLine($"Script file modified: {GetNormalizedFilePath(filePath)}");
                            CaptureScriptFile(filePath);
                            break;
                        case FILE_ACTION_REMOVED:
                            removedFiles.Add(filePath);
                            break;
                    }

                    offset += notifyInfo.NextEntryOffset;
                }

                if (removedFiles.Count > 0)
                {
                    Console.WriteLine($"Script files removed: {string.Join(", ", removedFiles)}");
                    removedFiles.Clear();
                }
            }
        }
        finally
        {
            Marshal.FreeHGlobal(bufferPtr);
            CloseHandle(directoryHandle);
        }
    }

    static string GetNormalizedFilePath(string filePath)
    {
        StringBuilder normalizedPath = new StringBuilder(256);
        GetFinalPathNameByHandle(CreateFile(
            filePath,
            0,
            0x0001, // FILE_SHARE_READ
            IntPtr.Zero,
            3, // OPEN_EXISTING
            0,
            IntPtr.Zero
        ), normalizedPath, normalizedPath.Capacity, 0);

        return normalizedPath.ToString();
    }

    static void CaptureScriptFile(string filePath)
    {
        // Perform analysis or capture actions here
        Console.WriteLine("Capturing script file for analysis: " + filePath);

        string fileName = Path.GetFileName(filePath);
        if (!string.IsNullOrEmpty(fileName) && File.Exists(filePath))
        {
            string destinationPath = Path.Combine("C:\\CapturedScripts", fileName);
            File.Copy(filePath, destinationPath, true);
        }
    }
}
