/* error figure it out at tcp buffer*/

using System;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

class Program
{
    private const int AF_INET = 2;
    private const int TCP_TABLE_OWNER_PID_ALL = 5;

    [StructLayout(LayoutKind.Sequential)]
    struct MIB_TCPROW_OWNER_PID
    {
        public uint state;
        public uint localAddr;
        public byte[] localPort;
        public uint remoteAddr;
        public byte[] remotePort;
        public int owningPid;
    }

    [DllImport("iphlpapi.dll", SetLastError = true)]
    private static extern uint GetExtendedTcpTable(IntPtr pTcpTable, ref int pdwSize, bool bOrder, int ulAf, int tableClass, int reserved);

    static void Main(string[] args)
    {
        MonitorTcpConnections();
        MonitorUdpListeners();

        Console.WriteLine("Monitoring for unexpected protocols...");
        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();
    }

    private static void MonitorTcpConnections()
    {
        try
        {
            IPGlobalProperties ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
            TcpConnectionInformation[] tcpConnections = ipGlobalProperties.GetActiveTcpConnections();

            foreach (TcpConnectionInformation tcpConnection in tcpConnections)
            {
                string localAddress = tcpConnection.LocalEndPoint.Address.ToString();
                string localPort = tcpConnection.LocalEndPoint.Port.ToString();
                string remoteAddress = tcpConnection.RemoteEndPoint.Address.ToString();
                string remotePort = tcpConnection.RemoteEndPoint.Port.ToString();
                int owningPid = GetOwningProcessId(tcpConnection.LocalEndPoint.Address, tcpConnection.LocalEndPoint.Port);

                Console.WriteLine($"TCP Connection: Local Address={localAddress}:{localPort}, Remote Address={remoteAddress}:{remotePort}, PID={owningPid}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to retrieve TCP connections. Error: {ex.Message}");
        }
    }

    private static void MonitorUdpListeners()
    {
        try
        {
            IPGlobalProperties ipGlobalProperties = IPGlobalProperties.GetIPGlobalProperties();
            IPEndPoint[] udpListeners = ipGlobalProperties.GetActiveUdpListeners();

            foreach (IPEndPoint udpListener in udpListeners)
            {
                string localAddress = udpListener.Address.ToString();
                string localPort = udpListener.Port.ToString();
                int owningPid = GetOwningProcessId(udpListener.Address, udpListener.Port);

                Console.WriteLine($"UDP Listener: Local Address={localAddress}:{localPort}, PID={owningPid}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Failed to retrieve UDP listeners. Error: {ex.Message}");
        }
    }

    private static int GetOwningProcessId(IPAddress localAddress, int localPort)
    {
        int size = 0;
        uint result = GetExtendedTcpTable(IntPtr.Zero, ref size, false, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0);
        if (result != 0)
        {
            Console.WriteLine($"Failed to retrieve TCP table. Error: {result}");
            return -1;
        }

        IntPtr tcpTablePtr = IntPtr.Zero;
        try
        {
            tcpTablePtr = Marshal.AllocHGlobal(size);
            result = GetExtendedTcpTable(tcpTablePtr, ref size, false, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0);
            if (result == 0)
            {
                int rowCount = Marshal.ReadInt32(tcpTablePtr);
                IntPtr rowPtr = tcpTablePtr + Marshal.SizeOf(typeof(int));

                for (int i = 0; i < rowCount; i++)
                {
                    MIB_TCPROW_OWNER_PID row = Marshal.PtrToStructure<MIB_TCPROW_OWNER_PID>(rowPtr);
                    string connectionLocalAddress = FormatIpAddress(row.localAddr);
                    int connectionLocalPort = BitConverter.ToUInt16(row.localPort.Reverse().ToArray(), 0);

                    if (connectionLocalAddress == localAddress.ToString() && connectionLocalPort == localPort)
                    {
                        return row.owningPid;
                    }

                    rowPtr += Marshal.SizeOf(typeof(MIB_TCPROW_OWNER_PID));
                }
            }
            else
            {
                Console.WriteLine($"Failed to retrieve TCP table. Error: {result}");
            }
        }
        finally
        {
            if (tcpTablePtr != IntPtr.Zero)
                Marshal.FreeHGlobal(tcpTablePtr);
        }

        return -1;
    }

    private static string FormatIpAddress(uint ipAddress)
    {
        byte[] ipBytes = BitConverter.GetBytes(ipAddress);
        return new IPAddress(ipBytes.Reverse().ToArray()).ToString();
    }
}
