using System;
using System.Runtime.InteropServices;
using System.Threading;

class ICSMonitor
{
    // Constants for monitoring network events
    private const int EVENT_OBJECT_NAMECHANGE = 0x800C;
    private const int WINEVENT_OUTOFCONTEXT = 0x0000;

    // Delegate for event callback
    private delegate void WinEventDelegate(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime);

    // Import Win32 API functions
    [DllImport("user32.dll")]
    private static extern IntPtr SetWinEventHook(uint eventMin, uint eventMax, IntPtr hmodWinEventProc, WinEventDelegate lpfnWinEventProc, uint idProcess, uint idThread, uint dwFlags);

    [DllImport("user32.dll")]
    private static extern bool UnhookWinEvent(IntPtr hWinEventHook);

    [DllImport("user32.dll")]
    private static extern int GetWindowText(IntPtr hWnd, System.Text.StringBuilder lpString, int nMaxCount);

    // Event callback function
    private static void WinEventCallback(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
    {
        const int MAX_WINDOW_TITLE_LENGTH = 256;
        var windowTitle = new System.Text.StringBuilder(MAX_WINDOW_TITLE_LENGTH);
        GetWindowText(hwnd, windowTitle, MAX_WINDOW_TITLE_LENGTH);

        // Check if the event is related to reading the asset's operating mode
        if (windowTitle.ToString().Contains("AssetOperatingMode"))
        {
            // Log the event or take necessary actions
            Console.WriteLine("Detected asset operating mode access: " + windowTitle);
        }
    }

    static void Main()
    {
        // Register the event hook
        WinEventDelegate eventDelegate = new WinEventDelegate(WinEventCallback);
        IntPtr hHook = SetWinEventHook(EVENT_OBJECT_NAMECHANGE, EVENT_OBJECT_NAMECHANGE, IntPtr.Zero, eventDelegate, 0, 0, WINEVENT_OUTOFCONTEXT);

        if (hHook == IntPtr.Zero)
        {
            Console.WriteLine("Failed to set WinEvent hook.");
            return;
        }

        Console.WriteLine("Monitoring ICS automation network protocols. Press any key to exit.");
        Console.ReadKey();

        // Unhook the event
        UnhookWinEvent(hHook);
    }
}
