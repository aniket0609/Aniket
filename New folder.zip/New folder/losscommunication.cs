using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

class Program
{
    // Constants for Win32 API functions
    private const int PROCESS_QUERY_INFORMATION = 0x0400;
    private const int STILL_ACTIVE = 259;

    // Win32 API function to check if a process is running
    [DllImport("kernel32.dll")]
    private static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

    // Win32 API function to retrieve the exit code of a process
    [DllImport("kernel32.dll")]
    private static extern bool GetExitCodeProcess(IntPtr hProcess, out uint lpExitCode);

    static void Main(string[] args)
    {
        string processName = "notepad++.exe"; // Replace with the actual process name to monitor

        // Monitor the process indefinitely
        while (true)
        {
            Process[] processes = Process.GetProcessesByName(processName);

            if (processes.Length == 0)
            {
                // The process is not running, so communications may be lost
                Console.WriteLine("Loss of communications detected!");
                // Additional actions or notifications can be added here

                // Wait for a period of time before checking again
                System.Threading.Thread.Sleep(5000); // 5 seconds
            }
            else
            {
                foreach (Process process in processes)
                {
                    // Check if the process has exited
                    if (process.HasExited)
                    {
                        // Get the exit code of the process
                        IntPtr hProcess = OpenProcess(PROCESS_QUERY_INFORMATION, false, process.Id);
                        GetExitCodeProcess(hProcess, out uint exitCode);

                        if (exitCode != STILL_ACTIVE)
                        {
                            // The process has exited, so communications may be lost
                            Console.WriteLine("Loss of communications detected!");
                            // Additional actions or notifications can be added here
                        }
                    }
                }

                // Wait for a period of time before checking again
                System.Threading.Thread.Sleep(5000); // 5 seconds
            }
        }
    }
}
