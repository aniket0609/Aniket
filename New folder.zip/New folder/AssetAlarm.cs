using System;
using System.Diagnostics;
using System.Management;

namespace AssetAlarmMonitor
{
    class Program
    {
        static void Main(string[] args)
        {
            // The name for the event log source you want to create and monitor
            string assetAlarmSource = "YourAssetAlarmSourceName";

            // Create the event log source (requires administrative privileges)
            if (!EventLog.SourceExists(assetAlarmSource))
            {
                EventLog.CreateEventSource(assetAlarmSource, "Application");
                Console.WriteLine($"Event log source '{assetAlarmSource}' created successfully.");
            }

            // Log a test event
            EventLog.WriteEntry(assetAlarmSource, "Test Asset Alarm Event", EventLogEntryType.Information);

            Console.WriteLine("Monitoring asset alarms. Press any key to stop.");

            ManagementEventWatcher watcher = new ManagementEventWatcher(
                new WqlEventQuery($"SELECT * FROM Win32_NTLogEvent WHERE LogFile = 'Application' AND SourceName = '{assetAlarmSource}'")
            );

            watcher.EventArrived += (sender, e) =>
            {
                ManagementBaseObject eventObj = e.NewEvent;
                Console.WriteLine($"Alarm Event: {eventObj["Message"]}");
            };

            watcher.Start();

            // Wait for user input to stop the monitoring.
            Console.ReadKey();

            watcher.Stop();
        }
    }
}
