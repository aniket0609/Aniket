using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

class LogonAnalyzer
{
    // Win32 API constants
    private const int EVENTLOG_SUCCESS = 0x0000;
    private const int ERROR_INSUFFICIENT_BUFFER = 122;

    [StructLayout(LayoutKind.Sequential)]
    private struct EVENTLOGRECORD
    {
        public int Length;
        public int Reserved;
        public int RecordNumber;
        public int TimeGenerated;
        public int TimeWritten;
        public int EventID;
        public short EventType;
        public short NumStrings;
        public short EventCategory;
        public short ReservedFlags;
        public int ClosingRecordNumber;
        public int StringOffset;
        public int UserSidLength;
        public int UserSidOffset;
        public int DataLength;
        public int DataOffset;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern IntPtr OpenEventLog(string server, string source);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool ReadEventLog(IntPtr hEventLog, int dwReadFlags, int dwRecordOffset,
                                            IntPtr lpBuffer, int nNumberOfBytesToRead, out int pnBytesRead,
                                            out int pnMinNumberOfBytesNeeded);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool CloseEventLog(IntPtr hEventLog);

    static void Main()
    {
        // Specify the event log name and query
        string eventLogName = "Security";
        string query = $"*[System/EventID={4625} or System/EventID={4624}]";

        // Continuously monitor the log
        while (true)
        {
            // Open the event log
            IntPtr hEventLog = OpenEventLog(null, eventLogName);
            if (hEventLog == IntPtr.Zero)
            {
                Console.WriteLine("Failed to open the event log.");
                return;
            }

            // Read the event log records
            int bytesToRead = 4096;
            int bytesRead = 0;
            IntPtr buffer = Marshal.AllocHGlobal(bytesToRead);

            while (ReadEventLog(hEventLog, 0x0001 | 0x0008, 0, buffer, bytesToRead, out bytesRead, out int minBytesNeeded))
            {
                int recordOffset = 0;
                while (recordOffset < bytesRead)
                {
                    EVENTLOGRECORD eventRecord = Marshal.PtrToStructure<EVENTLOGRECORD>(buffer + recordOffset);

                    // Extract relevant information from the event record
                    string logName = eventLogName;
                    int eventId = eventRecord.EventID;
                    string message = GetEventMessage(hEventLog, eventRecord);
                    DateTime eventTime = DateTime.FromFileTime(eventRecord.TimeGenerated);

                    if (eventId == 4625)
                    {
                        // Failed login attempt
                        Console.WriteLine("Failed login detected: " + message);
                    }
                    else if (eventId == 4624)
                    {
                        // Successful login
                        if (!IsWithinBusinessHours(eventTime))
                        {
                            Console.WriteLine("Successful login outside of office hours: " + message);
                        }
                    }

                    recordOffset += eventRecord.Length;
                }
            }

            Marshal.FreeHGlobal(buffer);
            CloseEventLog(hEventLog);

            // Delay for a specified interval before the next iteration
            int intervalMinutes = 1; // Adjust the interval as needed
            Thread.Sleep(TimeSpan.FromMinutes(intervalMinutes));
        }
    }

    static string GetEventMessage(IntPtr hEventLog, EVENTLOGRECORD eventRecord)
    {
        int dataOffset = eventRecord.DataOffset;
        int dataSize = eventRecord.DataLength;
        int bytesRead = 0;
        int minBytesNeeded = 0;

        IntPtr buffer = Marshal.AllocHGlobal(dataSize);
        if (!ReadEventLog(hEventLog, 0x0002, 0, buffer, dataSize, out bytesRead, out minBytesNeeded))
        {
            if (Marshal.GetLastWin32Error() == ERROR_INSUFFICIENT_BUFFER)
            {
                Marshal.FreeHGlobal(buffer);
                buffer = Marshal.AllocHGlobal(minBytesNeeded);
                dataSize = minBytesNeeded;

                if (!ReadEventLog(hEventLog, 0x0002, 0, buffer, dataSize, out bytesRead, out minBytesNeeded))
                {
                    Marshal.FreeHGlobal(buffer);
                    return string.Empty;
                }
            }
            else
            {
                Marshal.FreeHGlobal(buffer);
                return string.Empty;
            }	
        }

        string message = Marshal.PtrToStringAuto(buffer + dataOffset);
        Marshal.FreeHGlobal(buffer);
        return message;
    }

    static bool IsWithinBusinessHours(DateTime time)
    {
        // Implement your logic to determine if the given time is within normal business hours
        // You can define your own business hours and time ranges

        // Sample logic (replace with your own):
        TimeSpan startTime = new TimeSpan(9, 0, 0);  // Start of business hours (9:00 AM)
        TimeSpan endTime = new TimeSpan(17, 0, 0);  // End of business hours (5:00 PM)

        TimeSpan logTime = time.TimeOfDay;
        return logTime >= startTime && logTime <= endTime;
    }
}
