using Microsoft.Win32;
using System;
using System.Threading;

class Program
{
    static void Main()
    {
        string registryKeyPath = @"Software\Policies\Microsoft\Windows NT\DNSClient"; //provide registry key path 
        string valueName = "EnableMulticast";

        RegistryKey registryKey = Registry.LocalMachine.OpenSubKey(registryKeyPath, true);
        int previousValue = (int)registryKey.GetValue(valueName, 0);

        Console.WriteLine("Monitoring registry key changes. Press Enter to exit.");

        // Start a background thread to periodically check for changes
        Thread monitorThread = new Thread(() =>
        {
            while (true)
            {
                int currentValue = (int)registryKey.GetValue(valueName, 0);
                if (currentValue != previousValue)
                {
                    Console.WriteLine("EnableMulticast value changed: " + currentValue);
                    if (currentValue == 1)
                    {
                        Console.WriteLine("ALERT: EnableMulticast is now enabled!");
                        // Perform additional actions for the alert
                                        }
                    previousValue = currentValue;
                }
                Thread.Sleep(1000); // Wait for 1 second before checking again
            }
        });

        monitorThread.Start();

        Console.ReadLine(); // Wait for user input to exit

        // Cleanup
        monitorThread.Abort();
        registryKey.Close();
    }
}
