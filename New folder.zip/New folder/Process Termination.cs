using System;
using System.ServiceProcess;
using System.Diagnostics;


class Program
{
    static void Main()
    {
        // Specify the names of the processes or services to monitor
        string[] processNames = { "notepad++" };
        string[] serviceNames = { "Wuauserv" };

        // Create a new instance of the ProcessWatcher class
        ProcessWatcher watcher = new ProcessWatcher(processNames, serviceNames);

        // Attach event handlers for process and service termination
        watcher.ProcessTerminated += OnProcessTerminated;
        watcher.ServiceStopped += OnServiceStopped;

        // Start monitoring
        watcher.Start();

        Console.WriteLine("Monitoring processes and services. Press Enter to exit.");
        Console.ReadLine();

        // Stop monitoring
        watcher.Stop();
    }

    static void OnProcessTerminated(object sender, ProcessEventArgs e)
    {
        Console.WriteLine("Process terminated: " + e.ProcessName);
        // Add your code here to handle the termination of a process
    }

    static void OnServiceStopped(object sender, ServiceEventArgs e)
    {
        Console.WriteLine("Service stopped: " + e.ServiceName);
        // Add your code here to handle the stopping of a service
    }
}

class ProcessWatcher
{
    private string[] processNames;
    private string[] serviceNames;
    private bool isMonitoring;

    public event EventHandler<ProcessEventArgs> ProcessTerminated;
    public event EventHandler<ServiceEventArgs> ServiceStopped;

    public ProcessWatcher(string[] processNames, string[] serviceNames)
    {
        this.processNames = processNames;
        this.serviceNames = serviceNames;
        isMonitoring = false;
    }

    public void Start()
    {
        if (!isMonitoring)
        {
            isMonitoring = true;
            // Start monitoring processes
            foreach (string processName in processNames)
            {
                ProcessMonitor(processName);
            }

            // Start monitoring services
            foreach (string serviceName in serviceNames)
            {
                ServiceMonitor(serviceName);
            }
        }
    }

    public void Stop()
    {
        isMonitoring = false;
    }

    private void ProcessMonitor(string processName)
    {
        Process[] processes = Process.GetProcessesByName(processName);
        if (processes.Length == 0)
        {
            OnProcessTerminated(processName);
        }
    }

    private void ServiceMonitor(string serviceName)
    {
        ServiceController serviceController = new ServiceController(serviceName);
        if (serviceController.Status != ServiceControllerStatus.Running)
        {
            OnServiceStopped(serviceName);
        }
    }

    private void OnProcessTerminated(string processName)
    {
        ProcessTerminated?.Invoke(this, new ProcessEventArgs(processName));
    }

    private void OnServiceStopped(string serviceName)
    {
        ServiceStopped?.Invoke(this, new ServiceEventArgs(serviceName));
    }
}

class ProcessEventArgs : EventArgs
{
    public string ProcessName { get; private set; }

    public ProcessEventArgs(string processName)
    {
        ProcessName = processName;
    }
}

class ServiceEventArgs : EventArgs
{
    public string ServiceName { get; private set; }

    public ServiceEventArgs(string serviceName)
    {
        ServiceName = serviceName;
    }
}