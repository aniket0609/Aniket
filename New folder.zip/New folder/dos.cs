using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public class DoSAttackMonitor
{
    private const int LogCheckIntervalSeconds = 5;
    private const int MaxLogFileSizeBytes = 4096; // 1048576 =  1 MB

    private static volatile bool _isMonitoring;

    public static void Main()
    {
        // Start monitoring thread
        _isMonitoring = true;
        Thread monitoringThread = new Thread(MonitorLogs);
        monitoringThread.Start();

        // Stop monitoring thread
        Console.WriteLine("Press any key to stop monitoring...");
        Console.ReadKey();
        _isMonitoring = false;
        monitoringThread.Join();

        Console.WriteLine("Monitoring stopped. Press any key to exit.");
        Console.ReadKey();
    }

    private static void MonitorLogs()
    {
        try
        {
            while (_isMonitoring)
            {
                List<string> logFilePaths = GetLogFilePaths();

                foreach (string logFilePath in logFilePaths)
                {
                    var fileInfo = new FileInfo(logFilePath);
                    if (fileInfo.Length > MaxLogFileSizeBytes)
                    {
                        // Log file size exceeds the threshold, potential DoS attack
                        Console.WriteLine($"Potential DoS attack detected! Log file: {logFilePath}, size: {fileInfo.Length} bytes");
                        // Perform additional actions (e.g., notify, log, mitigate)

                        // Rename or delete the log file to prevent further growth
                        try
                        {
                            File.Move(logFilePath, $"{logFilePath}_{DateTime.Now:yyyyMMdd_HHmmss}");
                        }
                        catch (IOException)
                        {
                            // Failed to rename the file, handle the exception as needed
                        }
                    }
                }

                Thread.Sleep(LogCheckIntervalSeconds * 1000);
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An exception occurred in the monitoring thread: {ex}");
        }
    }

    private static List<string> GetLogFilePaths()
    {
        List<string> logFilePaths = new List<string>();

        // Search for log files in directories
        logFilePaths.AddRange(GetLogFilePathsInDirectory("D:\\Test_1"));
        logFilePaths.AddRange(GetLogFilePathsInDirectory("D:\\Test_2"));
        // Add more directory paths as needed

        return logFilePaths;
    }

    private static List<string> GetLogFilePathsInDirectory(string directoryPath)
    {
        List<string> logFilePaths = new List<string>();

        WIN32_FIND_DATA findData;
        IntPtr findHandle = FindFirstFile(Path.Combine(directoryPath, "*.log"), out findData);

        if (findHandle != INVALID_HANDLE_VALUE)
        {
            bool foundNextFile;
            do
            {
                string filePath = Path.Combine(directoryPath, findData.cFileName);
                if (File.Exists(filePath))
                {
                    logFilePaths.Add(filePath);
                }
                foundNextFile = FindNextFile(findHandle, out findData);
            } while (foundNextFile);

            FindClose(findHandle);
        }

        return logFilePaths;
    }

    #region Windows API

    private const int MAX_PATH = 260;
    private static readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct WIN32_FIND_DATA
    {
        public FileAttributes dwFileAttributes;
        public FILETIME ftCreationTime;
        public FILETIME ftLastAccessTime;
        public FILETIME ftLastWriteTime;
        public uint nFileSizeHigh;
        public uint nFileSizeLow;
        public uint dwReserved0;
        public uint dwReserved1;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = MAX_PATH)]
        public string cFileName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 14)]
        public string cAlternateFileName;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct FILETIME
    {
        public uint dwLowDateTime;
        public uint dwHighDateTime;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindFirstFile(string lpFileName, out WIN32_FIND_DATA lpFindFileData);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FindNextFile(IntPtr hFindFile, out WIN32_FIND_DATA lpFindFileData);

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FindClose(IntPtr hFindFile);

    #endregion
}
