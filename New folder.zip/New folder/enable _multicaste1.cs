using System;
using System.Runtime.InteropServices;
using Microsoft.Win32;

class Program
{
    // Constants for the Win32 API
    private const int REG_NOTIFY_CHANGE_NAME = 0x1;
    private const int REG_NOTIFY_CHANGE_ATTRIBUTES = 0x2;
    private const int REG_NOTIFY_CHANGE_LAST_SET = 0x4;
    private const int REG_NOTIFY_CHANGE_SECURITY = 0x8;

    private const int KEY_QUERY_VALUE = 0x1;
    private const int KEY_NOTIFY = 0x10;

    private const int WAIT_OBJECT_0 = 0;
    private const int WAIT_TIMEOUT = 0x102;
    private const int WAIT_FAILED = -1;

    // Import the necessary Win32 API functions
    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern int RegOpenKeyEx(IntPtr hKey, string lpSubKey, int ulOptions, int samDesired, out IntPtr phkResult);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern int RegNotifyChangeKeyValue(IntPtr hKey, bool bWatchSubtree, int dwNotifyFilter, IntPtr hEvent, bool fAsynchronous);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern int RegCloseKey(IntPtr hKey);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr CreateEvent(IntPtr lpEventAttributes, bool bManualReset, bool bInitialState, string lpName);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern int WaitForSingleObject(IntPtr hHandle, int dwMilliseconds);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool ResetEvent(IntPtr hEvent);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool CloseHandle(IntPtr hObject);

    static void Main()
    {
        string registryKeyPath = @"Software\Policies\Microsoft\Windows NT\DNSClient";
        string valueName = "EnableMulticast";

        IntPtr hKey;
        int result = RegOpenKeyEx(IntPtr.Zero, registryKeyPath, 0, KEY_QUERY_VALUE | KEY_NOTIFY, out hKey);
        if (result != 0)
        {
            Console.WriteLine("Failed to open registry key.");
            return;
        }

        IntPtr hEvent = CreateEvent(IntPtr.Zero, false, false, null);
        if (hEvent == IntPtr.Zero)
        {
            Console.WriteLine("Failed to create event.");
            RegCloseKey(hKey);
            return;
        }

        // Set up the registry change notification
        result = RegNotifyChangeKeyValue(hKey, true, REG_NOTIFY_CHANGE_LAST_SET, hEvent, true);
        if (result != 0)
        {
            Console.WriteLine("Failed to set up registry change notification.");
            RegCloseKey(hKey);
            CloseHandle(hEvent);
            return;
        }

        Console.WriteLine("Monitoring registry key changes. Press Enter to exit.");

        while (true)
        {
            int waitResult = WaitForSingleObject(hEvent, 1000);
            if (waitResult == WAIT_OBJECT_0)
            {
                // Registry key change event triggered
                int currentValue = (int)Registry.GetValue(registryKeyPath, valueName, 0);
                Console.WriteLine("EnableMulticast value changed: " + currentValue);
                if (currentValue == 1)
                {
                    Console.WriteLine("ALERT: EnableMulticast is now enabled!");
                    // Perform additional actions for the alert
                }

                // Reset the event
                ResetEvent(hEvent);
            }
            else if (waitResult == WAIT_TIMEOUT)
            {
                // Timeout, continue waiting
                continue;
            }
            else
            {
                Console.WriteLine("Error occurred while waiting for registry change event.");
                break;
            }

            if (Console.KeyAvailable)
            {
                Console.ReadLine(); // Wait for user input to exit
                break;
            }
        }

        // Cleanup
        RegCloseKey(hKey);
        CloseHandle(hEvent);
    }
}
