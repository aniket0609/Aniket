using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        string logName = "Security";
        string source = "Microsoft Windows security auditing";

        EventLog eventLog = new EventLog(logName);
        eventLog.EntryWritten += new EntryWrittenEventHandler(OnEntryWritten);
        eventLog.EnableRaisingEvents = true;

        Console.WriteLine("Monitoring logon activity. Press any key to exit.");
        Console.ReadKey();
    }

    static void OnEntryWritten(object sender, EntryWrittenEventArgs e)
    {
        EventLogEntry entry = e.Entry;
        if (entry.InstanceId == 4624 || entry.InstanceId == 4625) // Logon/Logoff event IDs
        {
            Console.WriteLine($"Event ID: {entry.InstanceId}, Message: {entry.Message}");
            // Perform further analysis or logging based on the event information
        }
    }
}
