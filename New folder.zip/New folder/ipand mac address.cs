using System;
using System.Collections.Generic;
using System.Net;
using System.Runtime.InteropServices;

class NetworkScanner
{
    static void Main()
    {
        List<MIB_IFROW> networkInterfaces = GetNetworkInterfaces();

        foreach (MIB_IFROW networkInterface in networkInterfaces)
        {
            if (networkInterface.OperStatus == IF_OPER_STATUS.IF_OPER_STATUS_UP)
            {
                Console.WriteLine("Interface Name: " + networkInterface.InterfaceName);
                Console.WriteLine("Interface Type: " + networkInterface.Type);
                Console.WriteLine("MAC Address: " + FormatMacAddress(networkInterface.PhysicalAddress));
                Console.WriteLine("IP Addresses:");

                List<IP_ADDRESS_STRING> ipAddresses = GetIPAddresses(networkInterface.Index);
                foreach (IP_ADDRESS_STRING ipAddress in ipAddresses)
                {
                    Console.WriteLine("  " + FormatIPAddress(ipAddress));
                }

                Console.WriteLine();
            }
        }
    }

    static List<MIB_IFROW> GetNetworkInterfaces()
    {
        List<MIB_IFROW> networkInterfaces = new List<MIB_IFROW>();

        uint bufferSize = 0;
        GetIfTable(IntPtr.Zero, ref bufferSize, true);

        IntPtr buffer = Marshal.AllocHGlobal((int)bufferSize);
        try
        {
            if (GetIfTable(buffer, ref bufferSize, true) != ERROR_SUCCESS)
            {
                throw new Exception("Failed to retrieve network interface table.");
            }

            MIB_IFTABLE ifTable = Marshal.PtrToStructure<MIB_IFTABLE>(buffer);
            IntPtr ifRowPtr = buffer + Marshal.SizeOf(ifTable.dwNumEntries);

            for (int i = 0; i < ifTable.dwNumEntries; i++)
            {
                MIB_IFROW ifRow = Marshal.PtrToStructure<MIB_IFROW>(ifRowPtr);
                networkInterfaces.Add(ifRow);

                ifRowPtr += Marshal.SizeOf<MIB_IFROW>();
            }
        }
        finally
        {
            Marshal.FreeHGlobal(buffer);
        }

        return networkInterfaces;
    }

    static List<IP_ADDRESS_STRING> GetIPAddresses(int interfaceIndex)
    {
        List<IP_ADDRESS_STRING> ipAddresses = new List<IP_ADDRESS_STRING>();

        IntPtr buffer = IntPtr.Zero;
        try
        {
            uint bufferSize = 0;
            GetIpAddrTable(IntPtr.Zero, ref bufferSize, true);

            buffer = Marshal.AllocHGlobal((int)bufferSize);

            if (GetIpAddrTable(buffer, ref bufferSize, true) != ERROR_SUCCESS)
            {
                throw new Exception("Failed to retrieve IP address table.");
            }

            MIB_IPADDRTABLE ipAddrTable = Marshal.PtrToStructure<MIB_IPADDRTABLE>(buffer);
            IntPtr ipAddrRowPtr = buffer + Marshal.SizeOf(ipAddrTable.dwNumEntries);

            for (int i = 0; i < ipAddrTable.dwNumEntries; i++)
            {
                MIB_IPADDRROW ipAddrRow = Marshal.PtrToStructure<MIB_IPADDRROW>(ipAddrRowPtr);
                if (ipAddrRow.dwIndex == interfaceIndex)
                {
                    ipAddresses.Add(ipAddrRow.Address);
                }

                ipAddrRowPtr += Marshal.SizeOf<MIB_IPADDRROW>();
            }
        }
        finally
        {
            if (buffer != IntPtr.Zero)
            {
                Marshal.FreeHGlobal(buffer);
            }
        }

        return ipAddresses;
    }

    static string FormatIPAddress(IP_ADDRESS_STRING ipAddress)
    {
        return ipAddress.String;
    }

    static string FormatMacAddress(byte[] macAddress)
    {
        return BitConverter.ToString(macAddress).Replace("-", ":");
    }

    const int ERROR_SUCCESS = 0;

    [StructLayout(LayoutKind.Sequential)]
    struct MIB_IFROW
    {
        public int Index;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
        public string InterfaceName;
        public uint Type;
        public int Mtu;
        public uint Speed;
        public uint PhysAddrLen;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] PhysicalAddress;
        public uint AdminStatus;
        public IF_OPER_STATUS OperStatus;
        public uint LastChange;
        public uint InOctets;
        public uint InUcastPkts;
        public uint InNUcastPkts;
        public uint InDiscards;
        public uint InErrors;
        public uint InUnknownProtos;
        public uint OutOctets;
        public uint OutUcastPkts;
        public uint OutNUcastPkts;
        public uint OutDiscards;
        public uint OutErrors;
        public uint OutQLen;
        public uint DescrLen;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
        public byte[] Description;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct MIB_IFTABLE
    {
        public uint dwNumEntries;
        [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = 1)]
        public MIB_IFROW[] table;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct MIB_IPADDRROW
    {
        public uint dwAddr;
        public int dwIndex;
        public uint dwMask;
        public uint dwBCastAddr;
        public uint dwReasmSize;
        public ushort unused1;
        public ushort unused2;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    struct IP_ADDRESS_STRING
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string String;
    }

    enum IF_OPER_STATUS : uint
    {
        IF_OPER_STATUS_UP = 1,
        IF_OPER_STATUS_DOWN = 2,
        IF_OPER_STATUS_TESTING = 3,
        IF_OPER_STATUS_UNKNOWN = 4,
        IF_OPER_STATUS_DORMANT = 5,
        IF_OPER_STATUS_NOT_PRESENT = 6,
        IF_OPER_STATUS_LOWER_LAYER_DOWN = 7
    }

    [DllImport("iphlpapi.dll", SetLastError = true)]
    static extern uint GetIfTable(IntPtr pIfTable, ref uint pdwSize, bool bOrder);

    [DllImport("iphlpapi.dll", SetLastError = true)]
    static extern uint GetIpAddrTable(IntPtr pIpAddrTable, ref uint pdwSize, bool bOrder);
}
