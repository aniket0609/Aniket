/*  it will monitor the specified event log (in this case, the "System" event log) for new events. 
It will continuously check for changes in the event log and retrieve any new events that occur.
Once a new event is detected, it will print out the relevant information about the event, including 
the event log name, event ID, event level, event time, task category, source, and message.   */
using System;
using System.Runtime.InteropServices;

class Program
{
    // Win32 API constants
    private const int EVENTLOG_SEQUENTIAL_READ = 0x0001;
    private const int EVENTLOG_BACKWARDS_READ = 0x0008;
    private const int WAIT_OBJECT_0 = 0x00000000;

    [StructLayout(LayoutKind.Sequential)]
    private struct EVENTLOGRECORD
    {
        public int Length;
        public int Reserved;
        public int RecordNumber;
        public int TimeGenerated;
        public int TimeWritten;
        public int EventID;
        public short EventType;
        public short NumStrings;
        public short EventCategory;
        public short ReservedFlags;
        public int ClosingRecordNumber;
        public int StringOffset;
        public int UserSidLength;
        public int UserSidOffset;
        public int DataLength;
        public int DataOffset;
    }

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern IntPtr OpenEventLog(string server, string source);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool ReadEventLog(IntPtr hEventLog, int dwReadFlags, int dwRecordOffset,
                                            IntPtr lpBuffer, int nNumberOfBytesToRead, out int pnBytesRead,
                                            out int pnMinNumberOfBytesNeeded);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool CloseEventLog(IntPtr hEventLog);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern int WaitForMultipleObjects(int nCount, IntPtr[] lpHandles, bool bWaitAll, int dwMilliseconds);

    static void Main()
    {
        // Specify the event log and event IDs to monitor
        string eventLogName = "System";
        int[] eventIds = { 4697, 7045 };

        // Open the event log
        IntPtr hEventLog = OpenEventLog(null, eventLogName);
        if (hEventLog == IntPtr.Zero)
        {
            Console.WriteLine("Failed to open the event log.");
            return;
        }

        Console.WriteLine("Monitoring for new events. Press any key to stop.");

        // Create an array with a single event handle
        IntPtr[] eventHandles = { hEventLog };

        // Event loop
        while (true)
        {
            // Wait for the event log to change
            int waitResult = WaitForMultipleObjects(eventHandles.Length, eventHandles, false, 1000);
            if (waitResult == WAIT_OBJECT_0)
            {
                // An event occurred, read the event log
                int bytesToRead = 4096;
                int bytesRead = 0;
                IntPtr buffer = Marshal.AllocHGlobal(bytesToRead);

                while (ReadEventLog(hEventLog, EVENTLOG_SEQUENTIAL_READ | EVENTLOG_BACKWARDS_READ, 0,
                                    buffer, bytesToRead, out bytesRead, out int minBytesNeeded))
                {
                    // Process the read events
                    int recordOffset = 0;
                    while (recordOffset < bytesRead)
                    {
                        EVENTLOGRECORD eventRecord = Marshal.PtrToStructure<EVENTLOGRECORD>(buffer + recordOffset);
                        string logName = eventLogName;
                        int eventId = eventRecord.EventID;
                        string level = GetEventLevel(eventRecord.EventType);
                        DateTime eventTime = DateTime.FromFileTime(eventRecord.TimeGenerated);
                        string taskCategory = eventRecord.EventCategory.ToString();
                        string source = eventLogName; // In this example, the source is the same as the event log name
                        string message = Marshal.PtrToStringAuto(buffer + recordOffset + eventRecord.StringOffset);

                        Console.WriteLine($"New event: LogName: {logName}, EventID: {eventId}, Level: {level}, " +
                                          $"Time: {eventTime}, TaskCategory: {taskCategory}, Source: {source}, Message: {message}");

                        recordOffset += eventRecord.Length;
                    }
                }

                Marshal.FreeHGlobal(buffer);

                if (bytesRead == 0 || bytesRead == -1)
                {
                    // No more records or an error occurred
                    break;
                }
            }

            if (Console.KeyAvailable)
            {
                // Stop monitoring if any key is pressed
                break;
            }
        }

        // Clean up resources
        CloseEventLog(hEventLog);
    }

    private static string GetEventLevel(short eventType)
    {
        switch (eventType)
        {
            case 0x0001:
                return "Error";
            case 0x0010:
                return "Information";
            case 0x0002:
                return "Warning";
            case 0x0004:
                return "Audit Success";
            case 0x0008:
                return "Audit Failure";
            default:
                return "Unknown";
        }
    }
}
