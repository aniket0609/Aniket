/*  Monitoring network traffic for anomalies:
For each TCP connection, it will show the local address (source IP address and port), remote address (destination IP address and port), and the owning process ID (PID). This information helps you analyze the network traffic and detect any anomalies or unexpected connections.

Monitoring for network traffic from unknown hosts:
It will display the IP addresses of any unknown hosts detected in the IPNet table. These are hosts for which the physical address (MAC address) is not available. This information can be useful in identifying potentially unauthorized or suspicious devices on the network. */



using System;
using System.Linq;
using System.Net;
using System.Runtime.InteropServices;
using System.Text;

namespace NetworkTrafficMonitor
{
    class Program
    {
        private const int ERROR_INSUFFICIENT_BUFFER = 122;
        private const int ERROR_SUCCESS = 0;
        private const int AF_INET = 2;

        [StructLayout(LayoutKind.Sequential)]
        private struct MIB_TCPROW_OWNER_PID
        {
            public uint State;
            public uint LocalAddr;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] LocalPort;
            public uint RemoteAddr;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] RemotePort;
            public uint OwningPid;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct MIB_IPNETROW
        {
            public uint Index;
            public uint PhysAddrLen;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
            public byte[] PhysAddr;
            public uint Address;
            public uint Type;
        }

        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern int GetExtendedTcpTable(IntPtr pTcpTable, ref int pdwSize, bool bOrder, int ulAf, TcpTableClass tableClass, int reserved);

        [DllImport("iphlpapi.dll")]
        private static extern int GetAdaptersInfo(byte[] pAdapterInfo, ref int pBufOutLen);

        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern uint GetIfTable(byte[] pIfTable, ref uint pdwSize, bool bOrder);

        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern int GetIfEntry(IntPtr pIfRow);

        [DllImport("iphlpapi.dll", SetLastError = true)]
        private static extern int GetIpNetTable(IntPtr pIpNetTable, ref int pdwSize, bool bOrder);

        [DllImport("iphlpapi.dll")]
        private static extern int FreeMibTable(IntPtr plpNetTable);

        [DllImport("ws2_32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int inet_ntoa(byte[] ip, StringBuilder buffer);

        private enum TcpTableClass
        {
            TCP_TABLE_BASIC_LISTENER,
            TCP_TABLE_BASIC_CONNECTIONS,
            TCP_TABLE_BASIC_ALL,
            TCP_TABLE_OWNER_PID_LISTENER,
            TCP_TABLE_OWNER_PID_CONNECTIONS,
            TCP_TABLE_OWNER_PID_ALL,
            TCP_TABLE_OWNER_MODULE_LISTENER,
            TCP_TABLE_OWNER_MODULE_CONNECTIONS,
            TCP_TABLE_OWNER_MODULE_ALL
        }

        private static string GetMacAddress(byte[] macBytes)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < macBytes.Length; i++)
            {
                sb.Append(macBytes[i].ToString("X2"));
                if (i != macBytes.Length - 1)
                    sb.Append("-");
            }
            return sb.ToString();
        }

        private static string GetIpAddress(uint ipAddr)
        {
            byte[] bytes = BitConverter.GetBytes(ipAddr);
            Array.Reverse(bytes); // Convert to little endian
            return new IPAddress(bytes).ToString();
        }

        private static void MonitorNetworkTraffic()
        {
            // Get the size of the TCP table
            int tcpTableSize = 0;
            GetExtendedTcpTable(IntPtr.Zero, ref tcpTableSize, true, AF_INET, TcpTableClass.TCP_TABLE_OWNER_PID_ALL, 0);

            // Allocate memory for the TCP table
            IntPtr tcpTablePtr = Marshal.AllocHGlobal(tcpTableSize);

            // Retrieve the TCP table
            int result = GetExtendedTcpTable(tcpTablePtr, ref tcpTableSize, true, AF_INET, TcpTableClass.TCP_TABLE_OWNER_PID_ALL, 0);

            if (result != ERROR_SUCCESS)
            {
                Console.WriteLine("Failed to retrieve TCP table.");
                Marshal.FreeHGlobal(tcpTablePtr);
                return;
            }

            // Get the number of entries in the TCP table
            int numEntries = Marshal.ReadInt32(tcpTablePtr);

            // Calculate the offset to the TCP row structures
            IntPtr tcpTableRowsPtr = tcpTablePtr + 4;

            // Read each TCP row and analyze the network traffic
            for (int i = 0; i < numEntries; i++)
            {
                IntPtr rowPtr = tcpTableRowsPtr + i * Marshal.SizeOf(typeof(MIB_TCPROW_OWNER_PID));
                var row = Marshal.PtrToStructure<MIB_TCPROW_OWNER_PID>(rowPtr);

                // Analyze the network traffic
                string localIpAddress = GetIpAddress(row.LocalAddr);
                string localPort = BitConverter.ToUInt16(row.LocalPort.Reverse().ToArray(), 0).ToString();
                string remoteIpAddress = GetIpAddress(row.RemoteAddr);
                string remotePort = BitConverter.ToUInt16(row.RemotePort.Reverse().ToArray(), 0).ToString();
                string owningPid = row.OwningPid.ToString();

                Console.WriteLine($"Local Address: {localIpAddress}:{localPort}");
                Console.WriteLine($"Remote Address: {remoteIpAddress}:{remotePort}");
                Console.WriteLine($"Owning PID: {owningPid}");
                Console.WriteLine();
            }

            // Free the memory allocated for the TCP table
            Marshal.FreeHGlobal(tcpTablePtr);
        }

        private static void MonitorUnknownHosts()
        {
            // Get the size of the IPNet table
            int ipNetTableSize = 0;
            GetIpNetTable(IntPtr.Zero, ref ipNetTableSize, false);

            // Allocate memory for the IPNet table
            IntPtr ipNetTablePtr = Marshal.AllocHGlobal(ipNetTableSize);

            // Retrieve the IPNet table
            int result = GetIpNetTable(ipNetTablePtr, ref ipNetTableSize, false);

            if (result != ERROR_SUCCESS)
            {
                Console.WriteLine("Failed to retrieve IPNet table.");
                Marshal.FreeHGlobal(ipNetTablePtr);
                return;
            }

            // Get the number of entries in the IPNet table
            int numEntries = Marshal.ReadInt32(ipNetTablePtr);

            // Calculate the offset to the IPNet row structures
            IntPtr ipNetTableRowsPtr = ipNetTablePtr + 4;

            // Read each IPNet row and check for unknown hosts
            for (int i = 0; i < numEntries; i++)
            {
                IntPtr rowPtr = ipNetTableRowsPtr + i * Marshal.SizeOf(typeof(MIB_IPNETROW));
                var row = Marshal.PtrToStructure<MIB_IPNETROW>(rowPtr);

                // Check if the host is unknown
                if (row.PhysAddrLen == 0)
                {
                    string ipAddress = GetIpAddress(row.Address);
                    Console.WriteLine($"Unknown Host: {ipAddress}");
                }
            }

            // Free the memory allocated for the IPNet table
            Marshal.FreeHGlobal(ipNetTablePtr);
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Monitoring network traffic for anomalies...");
            Console.WriteLine();

            MonitorNetworkTraffic();

            Console.WriteLine("Monitoring for network traffic from unknown hosts...");
            Console.WriteLine();

            MonitorUnknownHosts();

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }
    }
}
