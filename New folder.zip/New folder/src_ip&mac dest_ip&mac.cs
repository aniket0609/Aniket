using System;
using System.Net;
using System.Runtime.InteropServices;

class Program
{
    [DllImport("iphlpapi.dll", CharSet = CharSet.Auto)]
    public static extern int GetTcpTable(IntPtr pTcpTable, ref int pdwSize, bool bOrder);

    static void Main()
    {
        IntPtr tcpTable = IntPtr.Zero;
        int bufferSize = 0;

        // Get the required buffer size
        int result = GetTcpTable(tcpTable, ref bufferSize, true);

        // Allocate memory for the TCP table
        tcpTable = Marshal.AllocHGlobal(bufferSize);

        try
        {
            // Get the TCP table
            result = GetTcpTable(tcpTable, ref bufferSize, true);

            if (result == 0)
            {
                // Retrieve the number of entries in the TCP table
                int numEntries = Marshal.ReadInt32(tcpTable);

                // Get the first entry
                IntPtr currentEntry = tcpTable + 4;

                for (int i = 0; i < numEntries; i++)
                {
                    // Read the TCP table entry
                    MIB_TCPROW row = Marshal.PtrToStructure<MIB_TCPROW>(currentEntry);

                    // Print the network traffic information
                    Console.WriteLine("Source IP: {0}", FormatIP(row.dwLocalAddr));
                    Console.WriteLine("Source Port: {0}", row.dwLocalPort);
                    Console.WriteLine("Destination IP: {0}", FormatIP(row.dwRemoteAddr));
                    Console.WriteLine("Destination Port: {0}", row.dwRemotePort);
                    Console.WriteLine("Protocol: {0}", row.dwProtocol);
                    Console.WriteLine("Sequence Number: {0}", row.dwSequenceNumber);
                    Console.WriteLine("Flags: {0}", row.dwFlags);
                    Console.WriteLine("Payload: {0}", row.dwBytes);

                    Console.WriteLine();

                    // Move to the next entry
                    currentEntry += Marshal.SizeOf<MIB_TCPROW>();
                }
            }
            else
            {
                Console.WriteLine("Failed to retrieve TCP table.");
            }
        }
        finally
        {
            // Free the memory allocated for the TCP table
            Marshal.FreeHGlobal(tcpTable);
        }

        Console.ReadLine();
    }

    // Structure for the TCP table entry
    [StructLayout(LayoutKind.Sequential)]
    public struct MIB_TCPROW
    {
        public uint dwState;
        public uint dwLocalAddr;
        public uint dwLocalPort;
        public uint dwRemoteAddr;
        public uint dwRemotePort;
        public uint dwProcessId;
        public uint dwProtocol;
        public uint dwFlags;
        public uint dwBytes;
        public uint dwTimestampSeconds;
        public uint dwTimestampMilliseconds;
        public uint dwSequenceNumber;
    }

    // Helper method to format IP address from uint to string
    private static string FormatIP(uint ipAddress)
    {
        return new IPAddress(BitConverter.GetBytes(ipAddress)).ToString();
    }
}
