/* win32 api command 'CreateToolhelp32Snapshot', 'Process32First', 'Process32Next', 'OpenProcess', 
'QueryFullProcessImageName', and 'CloseHandle'  */
/* The code loops through all the processes and prints the process name and path for each new process created. 
It utilizes the GetProcessPath function to retrieve the process path based on the process ID.  */

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

class Program
{
    // Constants for the Win32 API
    private const int PROCESS_CREATE_PROCESS = 0x0080;
    private const int PROCESS_QUERY_INFORMATION = 0x0400;
    private const int PROCESS_VM_READ = 0x0010;

    // Import the necessary Win32 API functions
    [DllImport("kernel32.dll")]
    private static extern IntPtr CreateToolhelp32Snapshot(uint dwFlags, uint th32ProcessID);

    [DllImport("kernel32.dll")]
    private static extern bool Process32First(IntPtr hSnapshot, ref PROCESSENTRY32 lppe);

    [DllImport("kernel32.dll")]
    private static extern bool Process32Next(IntPtr hSnapshot, ref PROCESSENTRY32 lppe);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseHandle(IntPtr hObject);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr OpenProcess(int dwDesiredAccess, bool bInheritHandle, int dwProcessId);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool QueryFullProcessImageName(IntPtr hProcess, int dwFlags, [Out] char[] lpExeName, ref int lpdwSize);

    // Structure for process entry information
    [StructLayout(LayoutKind.Sequential)]
    private struct PROCESSENTRY32
    {
        public uint dwSize;
        public uint cntUsage;
        public uint th32ProcessID;
        public IntPtr th32DefaultHeapID;
        public uint th32ModuleID;
        public uint cntThreads;
        public uint th32ParentProcessID;
        public int pcPriClassBase;
        public uint dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szExeFile;
    }

    static void Main()
    {
        // Create a new process event watcher
        IntPtr snapshot = CreateToolhelp32Snapshot(2, 0); // 2 = TH32CS_SNAPPROCESS

        PROCESSENTRY32 processEntry = new PROCESSENTRY32();
        processEntry.dwSize = (uint)Marshal.SizeOf(typeof(PROCESSENTRY32));

        // Get the first process entry
        if (Process32First(snapshot, ref processEntry))
        {
            // Loop through all processes
            do
            {
                // Extract relevant information from the process entry
                string processName = processEntry.szExeFile;
                string processPath = GetProcessPath(processEntry.th32ProcessID);

                Console.WriteLine($"New process created: Name: {processName}, Path: {processPath}");
            }
            while (Process32Next(snapshot, ref processEntry));
        }

        // Close the snapshot handle
        CloseHandle(snapshot);

        Console.WriteLine("Monitoring for new process creation events. Press any key to stop.");
        Console.ReadKey();
    }

    // Function to retrieve the process path given the process ID
    private static string GetProcessPath(uint processId)
    {
        IntPtr processHandle = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, false, (int)processId);
        if (processHandle != IntPtr.Zero)
        {
            char[] buffer = new char[1024];
            int bufferSize = buffer.Length;
            if (QueryFullProcessImageName(processHandle, 0, buffer, ref bufferSize))
            {
                CloseHandle(processHandle);
                return new string(buffer, 0, bufferSize);
            }

            CloseHandle(processHandle);
        }
        
        return string.Empty;
    }
}
